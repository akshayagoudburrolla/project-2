"""
run_pipeline.py
-----------------
Convenience script: runs the full pipeline end-to-end.
    1. Preprocess + clean the credit risk dataset
    2. Generate EDA charts
    3. Train + tune models (Logistic Regression, Random Forest, XGBoost)
    4. Generate evaluation visualizations (ROC, PR, SHAP, etc.)

Usage: python run_pipeline.py   (run from the project root)
"""
import subprocess
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent / "src"

steps = ["preprocess.py", "eda.py", "train_model.py", "visualize_results.py"]

for step in steps:
    print(f"\n{'#' * 70}\n# Running {step}\n{'#' * 70}")
    result = subprocess.run([sys.executable, step], cwd=SRC)
    if result.returncode != 0:
        print(f"Step {step} failed. Stopping pipeline.")
        sys.exit(1)

print("\nPipeline complete. See the 'outputs/' folder for charts and metrics,")
print("and 'models/' for the saved trained model.")
