# XGBoost for Credit Risk

A complete, end-to-end credit default prediction system built around
**XGBoost**, benchmarked against Logistic Regression and Random Forest
baselines, with hyperparameter tuning, full evaluation, and SHAP-based
explainability — the kind of pipeline a real credit risk team would build
to decide who gets approved for a loan and how risky each borrower is.

---

## 1. Project Structure

```
credit_risk/
├── data/
│   ├── credit_risk_dataset.csv     # Raw data (32,581 loan applicants)
│   └── credit_risk_cleaned.csv     # Cleaned + feature-engineered (for EDA)
├── src/
│   ├── preprocess.py                # Cleaning, feature engineering, encoding
│   ├── eda.py                       # Exploratory data analysis charts
│   ├── train_model.py               # Trains + tunes all 4 models
│   ├── visualize_results.py         # ROC/PR curves, SHAP, confusion matrix
│   └── predict.py                   # CLI to score new loan applicants
├── models/                          # Saved trained model + artifacts
├── outputs/                         # Generated charts + metrics_summary.json
├── run_pipeline.py                  # Runs the full pipeline end-to-end
├── requirements.txt
└── README.md
```

## 2. Dataset

The [Kaggle Credit Risk Dataset](https://www.kaggle.com/datasets/laotse/credit-risk-dataset)
contains **32,581 loan applicants** with 11 features plus the target,
`loan_status` (1 = defaulted, 0 = repaid):

| Feature | Description |
|---|---|
| `person_age`, `person_income` | Borrower demographics |
| `person_home_ownership` | RENT / OWN / MORTGAGE / OTHER |
| `person_emp_length` | Years employed |
| `loan_intent` | Purpose (education, medical, venture, etc.) |
| `loan_grade` | A (lowest risk) through G (highest risk) |
| `loan_amnt`, `loan_int_rate` | Loan amount and interest rate |
| `loan_percent_income` | Loan amount as % of income |
| `cb_person_default_on_file` | Prior default on record (Y/N) |
| `cb_person_cred_hist_length` | Years of credit history |

**Real-world data quality issues found during EDA** (and handled in
`preprocess.py`):
- 895 missing `person_emp_length` values, 3,116 missing `loan_int_rate` values
- Data-entry errors: ages up to 144 years, employment lengths up to 123 years
  (and some rows where employment length exceeds age, which is impossible)
- ~2.8% of rows removed for implausible age/employment combinations;
  remaining missing values imputed with the median (grouped by loan grade
  for interest rate, since rate varies a lot by grade)
- **Class imbalance**: ~22% of loans in the cleaned data defaulted — handled
  via `scale_pos_weight` in XGBoost and `class_weight="balanced"` in the
  baselines, rather than naive resampling.

## 3. Methodology

1. **Cleaning** — remove implausible records, impute missing values.
2. **Feature engineering** — 3 derived ratios that capture relative risk:
   `income_to_loan_ratio`, `age_to_credit_history_ratio`,
   `emp_length_ratio_to_age`.
3. **Encoding** — label-encode the 4 categorical features.
4. **Modeling** — train and compare:
   - Logistic Regression (linear baseline)
   - Random Forest (non-linear baseline)
   - XGBoost, default hyperparameters
   - **XGBoost, tuned** via `RandomizedSearchCV` (30 iterations, 5-fold
     stratified CV, optimizing ROC-AUC) over `n_estimators`, `max_depth`,
     `learning_rate`, `subsample`, `colsample_bytree`, `min_child_weight`,
     `gamma`.
5. **Evaluation** — accuracy, precision, recall, F1, ROC-AUC, and PR-AUC
   (PR-AUC matters more than accuracy here, since the classes are
   imbalanced and missed defaults are costlier than false alarms).
6. **Explainability** — XGBoost gain-based feature importance + a SHAP
   summary plot showing how each feature pushes predictions toward or
   away from default, for individual borrowers.

## 4. How to Run

```bash
pip install -r requirements.txt

# Run the full pipeline (preprocess → EDA → train → visualize)
python run_pipeline.py

# Or run each stage individually from inside src/
cd src
python preprocess.py
python eda.py
python train_model.py
python visualize_results.py

# Score new applicants
python predict.py --demo                       # 3 built-in examples
python predict.py --csv path/to/applicants.csv  # your own data
```

`predict.py` expects a CSV with the 11 raw input columns listed in
Section 2 (no `loan_status` column needed) and outputs a default
probability plus a business-friendly risk tier (Very Low → Very High Risk).

## 5. Results

Full numbers in `outputs/metrics_summary.json`. Test-set performance:

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC | PR-AUC |
|---|---|---|---|---|---|---|
| Logistic Regression | 0.747 | 0.450 | 0.783 | 0.572 | 0.834 | 0.634 |
| Random Forest | 0.921 | 0.882 | 0.734 | 0.801 | 0.931 | 0.878 |
| XGBoost (default) | 0.926 | 0.845 | 0.802 | 0.823 | 0.950 | 0.908 |
| **XGBoost (tuned)** | 0.919 | 0.815 | **0.807** | **0.811** | **0.951** | **0.908** |

**XGBoost clearly outperforms both baselines on ROC-AUC and PR-AUC** — the
metrics that matter most given the class imbalance. Logistic Regression
struggles because the relationship between features like loan grade and
default risk isn't linear; tree-based models capture that naturally.

Tuning didn't dramatically beat the untuned XGBoost on this dataset (a
common, honest finding — XGBoost's defaults are already strong), but it
did **improve recall** (catching more true defaults) at a small precision
cost, which is usually the right trade-off for a lender: missing a default
is typically more expensive than over-flagging a safe borrower for review.

**Confusion matrix (tuned XGBoost, test set of 6,305 loans):**

|  | Predicted: No Default | Predicted: Default |
|---|---|---|
| **Actual: No Default** | 4,694 | 249 |
| **Actual: Default** | 263 | 1,099 |

The model correctly flags **80.7% of actual defaults** while keeping the
false-positive rate on good borrowers low (~5%).

### What drives the predictions (SHAP)

The top features, in order of impact:
1. **`income_to_loan_ratio`** — low income relative to loan size is the
   single strongest default signal
2. **`loan_percent_income`** — confirms the same pattern from a different
   angle
3. **`person_income`** — lower absolute income → higher risk
4. **`loan_grade`** — the credit bureau's own risk rating remains highly
   predictive even after modeling
5. **`person_home_ownership`** — renters carry higher risk than mortgage
   holders/owners

This lines up well with intuition and with standard credit risk practice:
**debt-to-income style ratios dominate**, which is reassuring from a model
validation standpoint — the model isn't picking up on spurious patterns.

## 6. Charts Generated (`outputs/`)

**EDA:**
- `target_distribution.png` — class balance (78% repaid / 22% defaulted)
- `default_rate_by_grade.png` — default rate climbs from 9.6% (grade A) to
  98.4% (grade G) — near-perfectly monotonic
- `default_rate_by_home_ownership.png`, `default_rate_by_intent.png`
- `loan_percent_income_by_status.png` — distribution overlap by outcome
- `correlation_heatmap.png`

**Model evaluation:**
- `model_comparison.png` — all 4 models, 5 metrics
- `roc_curves.png`, `pr_curves.png` — overlaid across all models
- `confusion_matrix.png` — tuned XGBoost
- `feature_importance.png` — XGBoost gain-based importance
- `shap_summary.png` — per-feature, per-prediction impact

## 7. Possible Extensions

- Threshold tuning beyond 0.5 based on a real cost matrix (cost of a missed
  default vs. cost of rejecting a good borrower)
- Calibrate probabilities (`CalibratedClassifierCV`) if scores will be
  used directly as PD (probability of default) estimates
- Add SMOTE/undersampling and compare against the `scale_pos_weight`
  approach used here
- Deploy via a simple Flask/FastAPI scoring endpoint or Streamlit dashboard
- Build a credit scorecard (points-based) on top of the model for
  regulatory/explainability requirements common in lending

## 8. Limitations

- This is a **single, static snapshot** dataset; a production credit model
  needs ongoing monitoring for population/feature drift as the borrower
  mix and macroeconomic conditions change.
- The dataset doesn't include time — there's no way to model *when* in
  the loan's life a default happens, only *whether* it does.
- Label encoding (vs. one-hot) is used for categorical features for
  simplicity with tree models; this is standard practice for XGBoost but
  worth noting if porting features to a linear model.
- Real lending decisions need fairness/bias auditing across protected
  classes before deployment — not performed here, since the dataset has
  no demographic attributes beyond age.
