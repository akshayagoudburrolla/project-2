"""
eda.py
-------
Generates exploratory data analysis charts from the cleaned dataset:
 1. Target class distribution (default vs non-default)
 2. Default rate by loan grade
 3. Default rate by home ownership
 4. Default rate by loan intent
 5. Loan percent income distribution by default status
 6. Correlation heatmap of numeric features
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUTS_DIR = BASE_DIR / "outputs"
OUTPUTS_DIR.mkdir(exist_ok=True)

sns.set_theme(style="whitegrid")


def load_clean():
    return pd.read_csv(DATA_DIR / "credit_risk_cleaned.csv")


def plot_target_distribution(df):
    counts = df["loan_status"].value_counts().sort_index()
    labels = ["Non-Default (0)", "Default (1)"]
    fig, ax = plt.subplots(figsize=(6, 5))
    colors = ["#4c72b0", "#c44e52"]
    ax.bar(labels, counts.values, color=colors)
    for i, v in enumerate(counts.values):
        ax.text(i, v + 200, f"{v}\n({v/counts.sum():.1%})", ha="center")
    ax.set_ylabel("Number of loans")
    ax.set_title("Loan Status Distribution")
    plt.tight_layout()
    plt.savefig(OUTPUTS_DIR / "target_distribution.png", dpi=150)
    plt.close()
    print("Saved target_distribution.png")


def plot_default_rate_by(df, col, title, filename, order=None):
    rates = df.groupby(col)["loan_status"].mean().sort_values(ascending=False)
    if order:
        rates = rates.reindex(order)
    fig, ax = plt.subplots(figsize=(8, 5))
    colors = sns.color_palette("Reds", len(rates))
    ax.bar(rates.index.astype(str), rates.values, color=colors)
    ax.set_ylabel("Default rate")
    ax.set_title(title)
    ax.set_ylim(0, max(rates.values) * 1.3)
    for i, v in enumerate(rates.values):
        ax.text(i, v + 0.01, f"{v:.1%}", ha="center", fontsize=9)
    plt.xticks(rotation=20)
    plt.tight_layout()
    plt.savefig(OUTPUTS_DIR / filename, dpi=150)
    plt.close()
    print(f"Saved {filename}")


def plot_loan_percent_income(df):
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.kdeplot(
        data=df, x="loan_percent_income", hue="loan_status",
        fill=True, common_norm=False, alpha=0.4, ax=ax,
        palette={0: "#4c72b0", 1: "#c44e52"}
    )
    ax.set_title("Loan-to-Income Ratio by Default Status")
    ax.set_xlabel("Loan amount as % of income")
    plt.tight_layout()
    plt.savefig(OUTPUTS_DIR / "loan_percent_income_by_status.png", dpi=150)
    plt.close()
    print("Saved loan_percent_income_by_status.png")


def plot_correlation_heatmap(df):
    numeric_df = df.select_dtypes(include=[np.number])
    corr = numeric_df.corr()
    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=ax)
    ax.set_title("Correlation Heatmap (Numeric Features)")
    plt.tight_layout()
    plt.savefig(OUTPUTS_DIR / "correlation_heatmap.png", dpi=150)
    plt.close()
    print("Saved correlation_heatmap.png")


def run():
    df = load_clean()
    plot_target_distribution(df)
    plot_default_rate_by(
        df, "loan_grade", "Default Rate by Loan Grade (A=lowest risk)",
        "default_rate_by_grade.png", order=sorted(df["loan_grade"].unique())
    )
    plot_default_rate_by(
        df, "person_home_ownership", "Default Rate by Home Ownership",
        "default_rate_by_home_ownership.png"
    )
    plot_default_rate_by(
        df, "loan_intent", "Default Rate by Loan Purpose",
        "default_rate_by_intent.png"
    )
    plot_loan_percent_income(df)
    plot_correlation_heatmap(df)


if __name__ == "__main__":
    run()
