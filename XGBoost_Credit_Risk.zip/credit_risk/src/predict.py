"""
predict.py
-----------
Scores new loan applicants with the trained XGBoost model and translates
the raw probability into a business-friendly risk tier.

Usage:
    python predict.py --demo
    python predict.py --csv path/to/new_applicants.csv

Input CSV must have these columns (same as the raw training data, no
loan_status / target column needed):
    person_age, person_income, person_home_ownership, person_emp_length,
    loan_intent, loan_grade, loan_amnt, loan_int_rate, loan_percent_income,
    cb_person_default_on_file, cb_person_cred_hist_length
"""

import argparse
import joblib
import pandas as pd
import numpy as np
from pathlib import Path
from io import StringIO

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"

RAW_COLS = [
    "person_age", "person_income", "person_home_ownership", "person_emp_length",
    "loan_intent", "loan_grade", "loan_amnt", "loan_int_rate",
    "loan_percent_income", "cb_person_default_on_file", "cb_person_cred_hist_length",
]


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["income_to_loan_ratio"] = df["person_income"] / df["loan_amnt"].replace(0, 1)
    df["age_to_credit_history_ratio"] = df["person_age"] / df["cb_person_cred_hist_length"].replace(0, 1)
    df["emp_length_ratio_to_age"] = df["person_emp_length"] / df["person_age"]
    return df


def risk_tier(prob: float) -> str:
    if prob < 0.10:
        return "Very Low Risk"
    elif prob < 0.30:
        return "Low Risk"
    elif prob < 0.55:
        return "Medium Risk"
    elif prob < 0.80:
        return "High Risk"
    else:
        return "Very High Risk"


def predict(df: pd.DataFrame) -> pd.DataFrame:
    model = joblib.load(MODELS_DIR / "xgboost_model.pkl")
    artifacts = joblib.load(MODELS_DIR / "preprocessing_artifacts.pkl")
    feature_cols = artifacts["feature_cols"]
    encoders = artifacts["encoders"]

    df_feat = engineer_features(df)
    X = df_feat[feature_cols].copy()

    for col, le in encoders.items():
        known = set(le.classes_)
        X[col] = X[col].astype(str).apply(lambda v: v if v in known else le.classes_[0])
        X[col] = le.transform(X[col])

    probs = model.predict_proba(X)[:, 1]
    preds = (probs >= 0.5).astype(int)

    results = df.copy()
    results["default_probability"] = np.round(probs, 4)
    results["predicted_status"] = ["Default" if p == 1 else "No Default" for p in preds]
    results["risk_tier"] = [risk_tier(p) for p in probs]
    return results


DEMO_APPLICANTS = """person_age,person_income,person_home_ownership,person_emp_length,loan_intent,loan_grade,loan_amnt,loan_int_rate,loan_percent_income,cb_person_default_on_file,cb_person_cred_hist_length
28,75000,MORTGAGE,6.0,EDUCATION,A,8000,7.5,0.11,N,5
22,18000,RENT,1.0,MEDICAL,E,12000,18.5,0.67,Y,2
35,95000,OWN,10.0,VENTURE,B,20000,10.2,0.21,N,8
"""


def run():
    parser = argparse.ArgumentParser(description="Score new loan applicants for default risk.")
    parser.add_argument("--csv", type=str, help="Path to CSV file with applicant data")
    parser.add_argument("--demo", action="store_true", help="Run on 3 built-in demo applicants")
    args = parser.parse_args()

    if args.csv:
        df = pd.read_csv(args.csv)
    else:
        df = pd.read_csv(StringIO(DEMO_APPLICANTS))
        print("Running on 3 built-in demo applicants (no --csv provided)...\n")

    results = predict(df)
    cols_to_show = ["person_age", "person_income", "loan_amnt", "loan_grade",
                     "default_probability", "predicted_status", "risk_tier"]
    print(results[cols_to_show].to_string(index=False))


if __name__ == "__main__":
    run()
