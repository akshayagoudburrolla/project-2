"""
visualize_results.py
----------------------
Generates model evaluation visualizations:
 1. Model comparison bar chart (all 4 models, 4 metrics)
 2. ROC curves (all models, overlaid)
 3. Precision-Recall curves (all models, overlaid) - important given imbalance
 4. Confusion matrix heatmap (tuned XGBoost)
 5. XGBoost built-in feature importance
 6. SHAP summary plot (explainability) for the tuned XGBoost model
"""

import json
import joblib
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from sklearn.metrics import roc_curve, auc, precision_recall_curve

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"
OUTPUTS_DIR = BASE_DIR / "outputs"
OUTPUTS_DIR.mkdir(exist_ok=True)

sns.set_theme(style="whitegrid")


def plot_model_comparison(summary):
    results = summary["results"]
    models = [r["model"] for r in results]
    metrics = ["accuracy", "precision", "recall", "f1_score", "roc_auc"]

    x = np.arange(len(models))
    width = 0.15
    fig, ax = plt.subplots(figsize=(12, 6))
    for i, metric in enumerate(metrics):
        vals = [r[metric] for r in results]
        ax.bar(x + i * width, vals, width, label=metric.replace("_", " ").title())

    ax.set_xticks(x + width * 2)
    ax.set_xticklabels(models, rotation=10)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Score")
    ax.set_title("Model Comparison: Credit Default Prediction")
    ax.legend(loc="lower right", ncol=2)
    plt.tight_layout()
    plt.savefig(OUTPUTS_DIR / "model_comparison.png", dpi=150)
    plt.close()
    print("Saved model_comparison.png")


def plot_roc_curves():
    eval_artifacts = joblib.load(MODELS_DIR / "eval_artifacts.pkl")
    all_probs = eval_artifacts["all_probs"]
    y_test = eval_artifacts["y_test"]

    fig, ax = plt.subplots(figsize=(7, 7))
    colors = sns.color_palette("Set1", len(all_probs))
    for (name, probs), color in zip(all_probs.items(), colors):
        fpr, tpr, _ = roc_curve(y_test, probs)
        roc_auc = auc(fpr, tpr)
        ax.plot(fpr, tpr, lw=2, color=color, label=f"{name} (AUC={roc_auc:.3f})")

    ax.plot([0, 1], [0, 1], linestyle="--", color="gray")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curves: Model Comparison")
    ax.legend(loc="lower right", fontsize=9)
    plt.tight_layout()
    plt.savefig(OUTPUTS_DIR / "roc_curves.png", dpi=150)
    plt.close()
    print("Saved roc_curves.png")


def plot_pr_curves():
    eval_artifacts = joblib.load(MODELS_DIR / "eval_artifacts.pkl")
    all_probs = eval_artifacts["all_probs"]
    y_test = eval_artifacts["y_test"]
    base_rate = y_test.mean()

    fig, ax = plt.subplots(figsize=(7, 7))
    colors = sns.color_palette("Set1", len(all_probs))
    for (name, probs), color in zip(all_probs.items(), colors):
        precision, recall, _ = precision_recall_curve(y_test, probs)
        pr_auc = auc(recall, precision)
        ax.plot(recall, precision, lw=2, color=color, label=f"{name} (AUC={pr_auc:.3f})")

    ax.axhline(base_rate, linestyle="--", color="gray", label=f"Baseline (default rate={base_rate:.2f})")
    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_title("Precision-Recall Curves: Model Comparison")
    ax.legend(loc="lower left", fontsize=9)
    plt.tight_layout()
    plt.savefig(OUTPUTS_DIR / "pr_curves.png", dpi=150)
    plt.close()
    print("Saved pr_curves.png")


def plot_confusion_matrix(summary):
    cm = np.array(summary["confusion_matrix_tuned_xgb"])
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(
        cm, annot=True, fmt="d", cmap="Blues",
        xticklabels=["No Default", "Default"],
        yticklabels=["No Default", "Default"], ax=ax
    )
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title("Confusion Matrix - Tuned XGBoost")
    plt.tight_layout()
    plt.savefig(OUTPUTS_DIR / "confusion_matrix.png", dpi=150)
    plt.close()
    print("Saved confusion_matrix.png")


def plot_feature_importance():
    model = joblib.load(MODELS_DIR / "xgboost_model.pkl")
    feature_cols = joblib.load(MODELS_DIR / "feature_cols.pkl")
    importances = model.feature_importances_
    idx = np.argsort(importances)[-12:]

    fig, ax = plt.subplots(figsize=(8, 7))
    ax.barh(np.array(feature_cols)[idx], importances[idx], color="#2c7fb8")
    ax.set_xlabel("Importance (gain-based)")
    ax.set_title("XGBoost Feature Importance (Top 12)")
    plt.tight_layout()
    plt.savefig(OUTPUTS_DIR / "feature_importance.png", dpi=150)
    plt.close()
    print("Saved feature_importance.png")


def plot_shap_summary():
    try:
        import shap
    except ImportError:
        print("shap not installed; skipping SHAP plot.")
        return

    model = joblib.load(MODELS_DIR / "xgboost_model.pkl")
    d = joblib.load(MODELS_DIR / "processed_data.pkl")
    X_test = d["X_test"]

    # sample for speed
    X_sample = X_test.sample(min(1000, len(X_test)), random_state=42)

    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_sample)

    plt.figure(figsize=(9, 7))
    shap.summary_plot(shap_values, X_sample, show=False, max_display=12)
    plt.title("SHAP Summary: Feature Impact on Default Risk")
    plt.tight_layout()
    plt.savefig(OUTPUTS_DIR / "shap_summary.png", dpi=150, bbox_inches="tight")
    plt.close()
    print("Saved shap_summary.png")


def run():
    with open(OUTPUTS_DIR / "metrics_summary.json") as f:
        summary = json.load(f)

    plot_model_comparison(summary)
    plot_roc_curves()
    plot_pr_curves()
    plot_confusion_matrix(summary)
    plot_feature_importance()
    plot_shap_summary()


if __name__ == "__main__":
    run()
