"""
preprocess.py
--------------
Loads the raw Credit Risk dataset, cleans known data-quality issues
(unrealistic ages/employment lengths, missing values), engineers a few
domain features, encodes categoricals, and splits into train/test sets.

Saves the train/test arrays and preprocessing artifacts (encoders, the
final feature list) to disk for reuse by training and prediction scripts.
"""

import pandas as pd
import numpy as np
import joblib
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
MODELS_DIR.mkdir(exist_ok=True)

RAW_FILE = DATA_DIR / "credit_risk_dataset.csv"

CATEGORICAL_COLS = [
    "person_home_ownership", "loan_intent", "loan_grade",
    "cb_person_default_on_file",
]
TARGET_COL = "loan_status"


def load_raw() -> pd.DataFrame:
    return pd.read_csv(RAW_FILE)


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """
    Removes data-entry errors found during EDA:
      - person_age beyond a plausible working-age range (>100)
      - person_emp_length beyond a plausible career length (>60 years)
      - rows where emp_length exceeds age (impossible, e.g. 21 yr old
        with 123 yrs experience)
    Missing person_emp_length / loan_int_rate are imputed with the median
    (robust to outliers, and both are moderately skewed).
    """
    df = df.copy()
    before = len(df)

    df = df[df["person_age"] <= 100]
    df = df[df["person_emp_length"] <= 60]
    df = df[df["person_emp_length"] <= df["person_age"]]

    removed = before - len(df)
    print(f"Removed {removed} rows with implausible age/employment values "
          f"({removed / before:.2%} of data).")

    df["person_emp_length"] = df["person_emp_length"].fillna(
        df["person_emp_length"].median()
    )
    df["loan_int_rate"] = df["loan_int_rate"].fillna(
        df.groupby("loan_grade")["loan_int_rate"].transform("median")
    )
    df["loan_int_rate"] = df["loan_int_rate"].fillna(df["loan_int_rate"].median())

    df = df.drop_duplicates().reset_index(drop=True)
    return df


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Adds a few interpretable, business-relevant derived features."""
    df = df.copy()
    df["income_to_loan_ratio"] = df["person_income"] / df["loan_amnt"].replace(0, 1)
    df["age_to_credit_history_ratio"] = df["person_age"] / df["cb_person_cred_hist_length"].replace(0, 1)
    df["emp_length_ratio_to_age"] = df["person_emp_length"] / df["person_age"]
    return df


def encode(df: pd.DataFrame):
    df = df.copy()
    encoders = {}
    for col in CATEGORICAL_COLS:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))
        encoders[col] = le
    return df, encoders


def run(test_size=0.2, random_state=42):
    print("Loading raw data...")
    df = load_raw()
    print(f"Raw shape: {df.shape}")

    df = clean(df)
    print(f"Shape after cleaning: {df.shape}")

    df = engineer_features(df)
    df, encoders = encode(df)

    feature_cols = [c for c in df.columns if c != TARGET_COL]
    X = df[feature_cols]
    y = df[TARGET_COL]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    print(f"\nTrain shape: {X_train.shape} | Test shape: {X_test.shape}")
    print(f"Default rate - train: {y_train.mean():.2%} | test: {y_test.mean():.2%}")

    joblib.dump(
        {
            "X_train": X_train, "X_test": X_test,
            "y_train": y_train, "y_test": y_test,
            "feature_cols": feature_cols,
        },
        MODELS_DIR / "processed_data.pkl",
    )
    joblib.dump(
        {"encoders": encoders, "categorical_cols": CATEGORICAL_COLS,
         "feature_cols": feature_cols},
        MODELS_DIR / "preprocessing_artifacts.pkl",
    )
    # save a cleaned, feature-engineered (but not yet encoded) copy for EDA charts
    df_for_eda = engineer_features(clean(load_raw()))
    df_for_eda.to_csv(DATA_DIR / "credit_risk_cleaned.csv", index=False)

    print(f"\nSaved processed data + artifacts to {MODELS_DIR}")
    print(f"Final feature set ({len(feature_cols)}): {feature_cols}")


if __name__ == "__main__":
    run()
