"""
train_model.py
---------------
Trains and evaluates models for credit default prediction:
  1. Baselines: Logistic Regression, Random Forest
  2. XGBoost (default hyperparameters)
  3. XGBoost tuned via RandomizedSearchCV (handles class imbalance via
     scale_pos_weight)

Reports accuracy, precision, recall, F1, ROC-AUC, and PR-AUC for all
models on the held-out test set, and saves the final tuned XGBoost model.
"""

import time
import json
import joblib
import numpy as np
from pathlib import Path
from scipy.stats import randint, uniform

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, confusion_matrix,
    classification_report
)
import xgboost as xgb

BASE_DIR = Path(__file__).resolve().parent.parent
MODELS_DIR = BASE_DIR / "models"
OUTPUTS_DIR = BASE_DIR / "outputs"
OUTPUTS_DIR.mkdir(exist_ok=True)


def load_data():
    return joblib.load(MODELS_DIR / "processed_data.pkl")


def evaluate(name, model, X_test, y_test):
    preds = model.predict(X_test)
    probs = model.predict_proba(X_test)[:, 1]
    return {
        "model": name,
        "accuracy": round(accuracy_score(y_test, preds), 4),
        "precision": round(precision_score(y_test, preds), 4),
        "recall": round(recall_score(y_test, preds), 4),
        "f1_score": round(f1_score(y_test, preds), 4),
        "roc_auc": round(roc_auc_score(y_test, probs), 4),
        "pr_auc": round(average_precision_score(y_test, probs), 4),
    }, preds, probs


def run():
    d = load_data()
    X_train, X_test = d["X_train"], d["X_test"]
    y_train, y_test = d["y_train"], d["y_test"]
    feature_cols = d["feature_cols"]

    scale_pos_weight = (y_train == 0).sum() / (y_train == 1).sum()
    print(f"Class imbalance ratio (neg/pos): {scale_pos_weight:.2f}")

    results = []
    all_probs = {}
    all_models = {}

    print("\n" + "=" * 70)
    print("BASELINE MODELS")
    print("=" * 70)

    baselines = {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "Random Forest": RandomForestClassifier(
            n_estimators=200, max_depth=12, class_weight="balanced",
            random_state=42, n_jobs=-1
        ),
    }
    for name, model in baselines.items():
        t0 = time.time()
        model.fit(X_train, y_train)
        metrics, preds, probs = evaluate(name, model, X_test, y_test)
        metrics["train_time_sec"] = round(time.time() - t0, 2)
        results.append(metrics)
        all_probs[name] = probs
        all_models[name] = model
        print(f"\n{name}:")
        for k, v in metrics.items():
            if k != "model":
                print(f"  {k}: {v}")

    print("\n" + "=" * 70)
    print("XGBOOST (DEFAULT HYPERPARAMETERS)")
    print("=" * 70)
    xgb_default = xgb.XGBClassifier(
        objective="binary:logistic", eval_metric="logloss",
        scale_pos_weight=scale_pos_weight, random_state=42,
        n_jobs=-1
    )
    t0 = time.time()
    xgb_default.fit(X_train, y_train)
    metrics, preds, probs = evaluate("XGBoost (default)", xgb_default, X_test, y_test)
    metrics["train_time_sec"] = round(time.time() - t0, 2)
    results.append(metrics)
    all_probs["XGBoost (default)"] = probs
    all_models["XGBoost (default)"] = xgb_default
    for k, v in metrics.items():
        if k != "model":
            print(f"  {k}: {v}")

    print("\n" + "=" * 70)
    print("XGBOOST - HYPERPARAMETER TUNING (RandomizedSearchCV)")
    print("=" * 70)
    param_dist = {
        "n_estimators": randint(100, 500),
        "max_depth": randint(3, 10),
        "learning_rate": uniform(0.01, 0.3),
        "subsample": uniform(0.6, 0.4),
        "colsample_bytree": uniform(0.6, 0.4),
        "min_child_weight": randint(1, 10),
        "gamma": uniform(0, 0.5),
    }
    base_xgb = xgb.XGBClassifier(
        objective="binary:logistic", eval_metric="logloss",
        scale_pos_weight=scale_pos_weight, random_state=42,
        n_jobs=-1
    )
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    search = RandomizedSearchCV(
        base_xgb, param_distributions=param_dist, n_iter=30,
        scoring="roc_auc", cv=cv, random_state=42, n_jobs=-1, verbose=0
    )
    t0 = time.time()
    search.fit(X_train, y_train)
    tune_time = time.time() - t0
    best_xgb = search.best_estimator_

    print(f"Best CV ROC-AUC: {search.best_score_:.4f}")
    print(f"Best params: {search.best_params_}")
    print(f"Tuning time: {tune_time:.1f}s ({search.n_splits_} folds x {30} iters)")

    metrics, preds, probs = evaluate("XGBoost (tuned)", best_xgb, X_test, y_test)
    metrics["train_time_sec"] = round(tune_time, 2)
    metrics["best_params"] = search.best_params_
    results.append(metrics)
    all_probs["XGBoost (tuned)"] = probs
    all_models["XGBoost (tuned)"] = best_xgb

    print(f"\nFinal XGBoost (tuned) test performance:")
    for k, v in metrics.items():
        if k not in ("model", "best_params"):
            print(f"  {k}: {v}")

    cm = confusion_matrix(y_test, preds)
    report = classification_report(y_test, preds, target_names=["No Default", "Default"])
    print("\nConfusion Matrix (tuned XGBoost):")
    print(cm)
    print("\nClassification Report (tuned XGBoost):")
    print(report)

    # Save best model + everything needed for prediction
    joblib.dump(best_xgb, MODELS_DIR / "xgboost_model.pkl")
    joblib.dump(feature_cols, MODELS_DIR / "feature_cols.pkl")

    summary = {
        "results": results,
        "confusion_matrix_tuned_xgb": cm.tolist(),
        "scale_pos_weight": round(float(scale_pos_weight), 4),
        "best_xgb_params": search.best_params_,
    }
    with open(OUTPUTS_DIR / "metrics_summary.json", "w") as f:
        json.dump(summary, f, indent=2, default=str)

    # also persist probs/preds for ROC/PR curve plotting later
    joblib.dump(
        {"all_probs": all_probs, "y_test": y_test},
        MODELS_DIR / "eval_artifacts.pkl",
    )

    print(f"\nSaved tuned XGBoost model to {MODELS_DIR / 'xgboost_model.pkl'}")
    print(f"Saved metrics summary to {OUTPUTS_DIR / 'metrics_summary.json'}")


if __name__ == "__main__":
    run()
